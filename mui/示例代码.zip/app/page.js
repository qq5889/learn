import React from 'react'

export default function Home() {
  return (
    <div>
      <div>
        <a href="/jss">jss 示例</a>
      </div>
      <div>
        <a href="/styled">styled 示例</a>
      </div>
      <div>
        <a href="/bar">组件封装</a>
      </div>
    </div>
  )
}
