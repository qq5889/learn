import { GuiFoo } from './foo'
import { GuiMenu, GuiMenuItem } from './menu'

const components = {
  GuiFoo,
  // GuiMenu,
  // GuiMenuItem,
}

export default components
