export const GuiMenu = {
  // variants: [
  //   {
  //     props: { size: 'medium' },
  //     style: {
  //       padding: '5px 16px',
  //       fontSize: 50,
  //     },
  //   },
  //   {
  //     props: { size: 'large' },
  //     style: {
  //       fontSize: 80,
  //     },
  //   },
  // ],
  styleOverrides: {
    root: {
      padding: 20,
      background: 'yellow',
    },
  },
}

export const GuiMenuItem = {
  styleOverrides: {
    root: {
      color: 'red',
    },
    icon: {
      color: 'red',
    },
  },
}
